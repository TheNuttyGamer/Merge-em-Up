﻿using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "newTrader", menuName = "Trader")]
public class TraderTemplate : ScriptableObject
{
    public new string name;
    public string flavourText;
    public Sprite face;
    public List<Trades> trades = new List<Trades>();
}
