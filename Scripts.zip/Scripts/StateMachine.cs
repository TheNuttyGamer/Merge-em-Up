﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StateMachine : MonoBehaviour
{
    private bool debugFix;
    public AudioSource audioSource;
    public AudioClip changeState;
    public static int day = -1;
    public TextMeshProUGUI dayText;
    public enum State { playerTurn, rivalTurn, merge, NoAction }
    public static State state;
    public delegate void Event();
    public static Event onStartTrade;
    public static Event onPlayerTurnOver;
    public static Event onRivalTurnOver;
    public static Event onRivalStopTrading;
    public static Event onPlayerStopTrading;
    public static Event onPlayerStopMerging;
    public static Event onRivalStopMerging;
    public static Event onMergeStart;
    public static Event onMergeEnd;

    public Text actualTurn;

    void Start()
    {
        onStartTrade?.Invoke();
    }

    void OnEnable()
    {
        onStartTrade += StartTrade;
        onMergeStart += MergeStart;
        onMergeEnd += DayOver;
        onMergeEnd += ChangeState;
        onStartTrade += ChangeState;
        onMergeStart += ChangeState;
    }

    void OnDisable()
    {
        onStartTrade -= StartTrade;
        onMergeStart -= MergeStart;
        onMergeEnd -= DayOver;
        onStartTrade -= ChangeState;
        onMergeEnd -= ChangeState;
    }

    void ChangeState()
    {
        if (debugFix)
        {
            audioSource.PlayOneShot(changeState);
        }
        else { debugFix = true; }
    }

    void StartTrade()
    {
        day++;
        switch (day)
        {
            case 0:
                dayText.text = "Monday";
                break;
            case 1:
                dayText.text = "Tuesday";
                break;
            case 2:
                dayText.text = "Wednesday";
                break;
            case 3:
                dayText.text = "Thursday";
                break;
            case 4:
                dayText.text = "Friday";
                break;
            case 5:
                dayText.text = "Saturday";
                break;
            case 6:
                dayText.text = "Sunday (last day!)";
                break;
            default:
                dayText.text = "Error: 01, please tell Nutty";
                break;
        }
    }
    void MergeStart() { state = State.merge; }
    void DayOver() { state = State.NoAction; }
}
