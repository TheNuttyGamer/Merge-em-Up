﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rival : MonoBehaviour
{
    private GameFlow gameFlow;
    public GameObject tradeArea;

    void Start()
    {
        gameFlow = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameFlow>(); 
    }

    public void TradeDecisionDelay() { StartCoroutine(TradeDecision()); }
    public void MergeDecisionDelay() { StartCoroutine(MergeDecision()); }

    IEnumerator TradeDecision()
    {
        yield return new WaitForSeconds(3f);
        if (gameFlow == null) { gameFlow = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameFlow>(); }
        List<Trader> currentTraders = tradeArea.transform.GetComponentsInChildren<Trader>().ToList();
        List<Trader> tradeableTraders = currentTraders.FindAll(x => x.availableToRival);
        
        if (tradeableTraders.Count > 0) { tradeableTraders[0].onInitiateTrade(gameFlow.rivalDeck, gameFlow.rivalDeckArea, false); }
        else { StateMachine.onRivalStopTrading(); }
    }

    IEnumerator MergeDecision()
    {
        List<Card> sortedCard = FindDupes(gameFlow.rivalDeck).ToList();
        while (true)
        {
            yield return new WaitForSeconds(2f);
            if (sortedCard.Count < 2)
            {
                StateMachine.onRivalStopMerging?.Invoke();
                yield break;
            }
            else if (sortedCard[0].template == sortedCard[1].template)
            {
                gameFlow.RivalMerge(sortedCard[0], sortedCard[1]);
                sortedCard = FindDupes(gameFlow.rivalDeck).ToList();
            }
            else
            {
                StateMachine.onRivalStopMerging?.Invoke();
                yield break;
            }
        }
    }

    Card[] FindDupes(List<Card> cards)
    {
        List<CardTemplate> appeared = new List<CardTemplate>();
        foreach (Card k in cards)
        {
            if(k.template.stage == 4) { continue; }
            if (appeared.Contains(k.template) == false) { appeared.Add(k.template); }
            else
            {
                appeared.Add(k.template);
                return gameFlow.rivalDeck.FindAll(x => x.template == k.template).ToArray();
            }
        }
        return new Card[1];
    }
}
