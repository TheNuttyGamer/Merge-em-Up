﻿using UnityEngine;

public class Jukebox : MonoBehaviour
{
    public AudioSource audioSource;

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
        audioSource.Play();
    }

    public void MuteUnmute()
    {
        if (audioSource.mute)
        {
            audioSource.mute = false;
        }
        else
        {
            audioSource.mute = true;
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            MuteUnmute();
        }
    }
}
