﻿using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Trader : MonoBehaviour
{
    [SerializeField]
    public Initialiser initialiser = new Initialiser();
    public TraderTemplate template;
    public Trades trading;
    public Button tradeButton;
    private GameFlow gameFlow;
    public bool availableToRival;

    public delegate void OnDeckChange();
    public delegate void OnInitiateTrade(List<Card> deck, GameObject deckArea, bool player);
    public static OnDeckChange onDeckChange;
    public OnInitiateTrade onInitiateTrade;

    void Start()
    {
        if (gameFlow == null) { gameFlow = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameFlow>(); }
        CheckValidity();
        tradeButton.onClick.AddListener(ClickTrade);
    }

    void OnEnable()
    {
        onDeckChange += CheckValidity;
        StateMachine.onPlayerTurnOver += Disable;
        StateMachine.onRivalTurnOver += CheckValidity;
        StateMachine.onMergeStart += Die;
        StateMachine.onPlayerTurnOver += Disable;
        onInitiateTrade += InitiateTrade;
    }

    void OnDisable()
    {
        onDeckChange -= CheckValidity;
        StateMachine.onPlayerTurnOver -= Disable;
        StateMachine.onRivalTurnOver -= CheckValidity;
        StateMachine.onPlayerTurnOver += Disable;
        StateMachine.onMergeStart -= Die;
        onInitiateTrade -= InitiateTrade;
    }

    public void Initialise(TraderTemplate trader)
    {
        template = trader;
        trading = TradePicker();
        initialiser.Initialise(trader, trading);
    }

    void CheckValidity()
    {
        if(StateMachine.state == StateMachine.State.rivalTurn)
        {
            return;
        }
        if(gameFlow == null) { gameFlow = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameFlow>(); }
        
        foreach (CardTemplate k in trading.want)
        {
            List<Card> matches = gameFlow.playerDeck.FindAll(x => x.template == k);
            if (matches.Count == 0 || matches.Any(x => x == null))
            {
                tradeButton.interactable = false;
            }
            else if(matches.Count >= trading.want.Count)
            {
                tradeButton.interactable = true;
            }
            else
            {
                tradeButton.interactable = false;
            }
        }

        foreach (CardTemplate k in trading.want)
        {
            List<Card> matches = gameFlow.rivalDeck.FindAll(x => x.template == k);
            if (matches.Count == 0)
            {
                availableToRival = false;
            }
            else if (matches.Count >= trading.want.Count)
            {
                availableToRival = true;
            }
            else
            {
                availableToRival = false;
            }
        }
    }

    Trades TradePicker()
    {
        List<Trades> potentialTrades = template.trades.FindAll(x => x.day <= StateMachine.day);
        return potentialTrades[Random.Range(0,potentialTrades.Count)];
    }

    void ClickTrade()
    {
        gameFlow.DeselectAll();
        GameFlow.onRemoveTemplateCards(trading.want.ToArray(), gameFlow.playerDeck);
        GameFlow.onNewCards(trading.have.ToArray(), gameFlow.playerDeck, gameFlow.playerDeckArea);
        StateMachine.onPlayerTurnOver();
        Destroy(gameObject);
    }

    void Enable()
    {
        tradeButton.interactable = true;
    }

    void Disable()
    {
        if(tradeButton != null)
        {
            tradeButton.interactable = false;
        }
    }

    void Die()
    {
        Destroy(gameObject);
    }

    void InitiateTrade(List<Card> deck, GameObject deckArea, bool player)
    {
        GameFlow.onRemoveTemplateCards(trading.want.ToArray(), deck);
        GameFlow.onNewCards(trading.have.ToArray(), deck, deckArea);
        if (player) { StateMachine.onPlayerTurnOver(); print("Initiate bug");} else if (gameFlow.playerGo) { StateMachine.onRivalTurnOver(); } else { StateMachine.onPlayerTurnOver(); }
        Destroy(gameObject);
    }

    [System.Serializable]
    public class Initialiser
    {
        private TraderTemplate thisTrader;
        private Trades trading;
        public TextMeshProUGUI traderName;
        public TextMeshProUGUI offerText;
        public Image face;

        public void Initialise(TraderTemplate trader, Trades trading)
        {
            thisTrader = trader;
            this.trading = trading;
            InitialiseTrader();
        }

        void InitialiseTrader()
        {
            traderName.text = thisTrader.name;
            string offerText = "Want: ";
            List<CardTemplate> distinctWant = trading.want.Distinct().ToList();
            List<CardTemplate> distinctHave = trading.have.Distinct().ToList();
            List<CardTemplate> occured = new List<CardTemplate>();
            for (int k = 0; k < distinctWant.Count; k++)
            {
                if (occured.Contains(trading.want[k])) { k--; continue; }
                if (k > 0) { offerText += "\nWant:"; }
                offerText += trading.want.FindAll(x => x == trading.want[k]).Count.ToString() + " | " + trading.want[k].type.ToString() + " Type/s | Stage: " + trading.want[k].stage;
                occured.Add(trading.want[k]);
            }
            offerText += ". \n\nHave: ";
            occured.Clear();
            for (int k = 0; k < distinctWant.Count; k++)
            {
                if (occured.Contains(trading.have[k])) { k--; continue; }
                if (k > 0) { offerText += "\nHave:"; }
                offerText += trading.have.FindAll(x => x == trading.have[k]).Count.ToString() + " | " + trading.have[k].type.ToString() + " Type/s | Stage: " + trading.have[k].stage;
                occured.Add(trading.have[k]);
            }
            face.sprite = thisTrader.face;
            this.offerText.text = offerText;
        }
    }
}
