﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class Card : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler
{
    [SerializeField]
    public Initialiser initialiser = new Initialiser();
    public CardTemplate template;
    public GameObject selection;
    public Vector3 defaultScale;

    void Start()
    {
        defaultScale = transform.localScale;
    }

    public void OnPointerEnter(PointerEventData data)
    {
        transform.localScale = new Vector3(defaultScale.x * 2, defaultScale.y * 2);
    }

    public void OnPointerExit(PointerEventData data)
    {
        transform.localScale = new Vector3(defaultScale.x, defaultScale.y);
    }

    public void OnPointerDown(PointerEventData data)
    {
        if(data.button == PointerEventData.InputButton.Left)
        {
            GameFlow.onSelected(this);
        }
        else if(data.button == PointerEventData.InputButton.Right)
        {
            GameFlow.onDeselected(this);
        }
    }

    public void Initialise(CardTemplate card)
    {
        template = card;
        initialiser.Initialise(card);
    }

    [System.Serializable]
    public class Initialiser
    {
        private CardTemplate thisCard;
        public TextMeshProUGUI cardName;
        public Image face;
        public Image stage;
        public Image type;
        public Image border;
        public TextMeshProUGUI description;
        public TextMeshProUGUI attack;
        public TextMeshProUGUI hp;

        public Sprite nothingType;
        public Sprite fireType;
        public Sprite waterType;
        public Sprite groundType;

        public Sprite stage0;
        public Color stage0Colour;
        public Sprite stage1;
        public Color stage1Colour;
        public Sprite stage2;
        public Color stage2Colour;
        public Sprite stage3;
        public Color stage3Colour;
        public Sprite DX;
        public Sprite dxStageColour;

        public void Initialise(CardTemplate card)
        {
            thisCard = card;
            InitialiseCard();
        }

        void InitialiseCard()
        {
            cardName.text = thisCard.name;
            face.sprite = thisCard.face;
            description.text = thisCard.description;
            switch (thisCard.type)
            {
                case CardTemplate.Type.Fire:
                    type.sprite = fireType;
                    break;
                case CardTemplate.Type.Water:
                    type.sprite = waterType;
                    break;
                case CardTemplate.Type.Ground:
                    type.sprite = groundType;
                    break;
                case CardTemplate.Type.Nothing:
                    type.sprite = nothingType;
                    break;
                default:
                    break;
            }
            switch (thisCard.stage)
            {
                case 0:
                    stage.sprite = stage0;
                    border.color = stage0Colour;
                    break;
                case 1:
                    stage.sprite = stage1;
                    border.color = stage1Colour;
                    break;
                case 2:
                    stage.sprite = stage2;
                    border.color = stage2Colour;
                    break;
                case 3:
                    stage.sprite = stage3;
                    border.color = stage3Colour;
                    break;
                case 4:
                    stage.sprite = DX;
                    border.color = new Color(1, 1, 1, 1);
                    border.sprite = dxStageColour;
                    break;
            }
            attack.text = thisCard.attack.ToString();
            hp.text = thisCard.maxHealth.ToString();
        }
    }
}
