﻿using System.Collections;
using UnityEngine;
using TMPro;

public class Result : MonoBehaviour
{
    public int playerScore = 0;
    public int rivalScore = 0;
    public AudioSource audioSource;
    public AudioClip revealText;
    public TextMeshProUGUI resultText;
    public TextMeshProUGUI bigScore;
    public TextMeshProUGUI smallScore;

    void OnLevelWasLoaded(int level)
    {
        if(level == 2)
        {
            resultText = GameObject.FindGameObjectWithTag("ResultText").GetComponent<TextMeshProUGUI>();
            bigScore = GameObject.FindGameObjectWithTag("BigText").GetComponent<TextMeshProUGUI>();
            smallScore = GameObject.FindGameObjectWithTag("SmallText").GetComponent<TextMeshProUGUI>();
            StartCoroutine(Results());
        }
    }

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }

    IEnumerator Results()
    {
        resultText.text = "";
        bigScore.text = "";
        smallScore.text = "";
        GameObject.FindGameObjectWithTag("Jukebox").GetComponent<Jukebox>().MuteUnmute();
        audioSource.PlayOneShot(revealText);
        yield return new WaitForSeconds(1.5f);
        audioSource.PlayOneShot(revealText);
        resultText.text += "The ";
        yield return new WaitForSeconds(0.4f);
        audioSource.PlayOneShot(revealText);
        resultText.text += "results ";
        yield return new WaitForSeconds(0.4f);
        audioSource.PlayOneShot(revealText);
        resultText.text += "are ";
        yield return new WaitForSeconds(0.4f);
        audioSource.PlayOneShot(revealText);
        resultText.text += "in... ";
        yield return new WaitForSeconds(2f);
        audioSource.PlayOneShot(revealText);
        resultText.text += "\nwith a score of:";
        yield return new WaitForSeconds(2f);
        audioSource.PlayOneShot(revealText);
        bigScore.text += playerScore + ":";
        yield return new WaitForSeconds(2f);
        audioSource.PlayOneShot(revealText);
        bigScore.text += rivalScore.ToString();
        yield return new WaitForSeconds(2f);
        GameObject.FindGameObjectWithTag("Jukebox").GetComponent<Jukebox>().MuteUnmute();
        if (playerScore > rivalScore)
        {
            smallScore.text = "YOU WIN! Yayyy :D! You have beaten the bratty little kid and proven yourself victorious." +
                "\n\nThank you so much for playing my game :). If you want to play again, reload the page.";
        }
        else if(rivalScore > playerScore)
        {
            smallScore.text = "Noo, you've been defeated D: - bested by a little kid. Better luck next time." +
                "\n\nThank you so much for playing my game :). If you want to play again, reload the page.";
        }
        else
        {
            smallScore.text = "A - a - a draw?? No one really knows what to think and the bratty kid runs away. I guess - you're the winner?... Yay?" +
                "\n\nThank you so much for playing my game :). If you want to play again, reload the page.";
        }
    }
}
