﻿using System.Collections.Generic;
using UnityEngine;

public class GameRegister : MonoBehaviour
{
    public List<CardTemplate> allCards = new List<CardTemplate>();
    public List<TraderTemplate> allTraders = new List<TraderTemplate>();
}