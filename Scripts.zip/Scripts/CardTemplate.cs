﻿using UnityEngine;

[CreateAssetMenu(fileName = "newCard", menuName = "Card")]
public class CardTemplate : ScriptableObject
{
    public enum Type { Fire, Water, Ground, Nothing }
    public new string name;
    public Sprite face;
    public string description;
    public int stage;
    public Type type;
    public int attack;
    public int maxHealth;
}
