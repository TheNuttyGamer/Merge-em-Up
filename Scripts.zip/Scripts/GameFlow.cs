﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class GameFlow : MonoBehaviour
{
    public GameRegister gameRegister;
    public List<Card> playerDeck = new List<Card>();
    public List<Card> rivalDeck = new List<Card>();
    public Rival rival;
    public Result result;
    public TextMeshProUGUI rivalState;

    public int playerScore = 0;
    public int rivalScore = 0;

    public GameObject mainCanvas;
    public CardTemplate defaultCard;
    public GameObject emptyCard;
    public GameObject emptyOffer;
    public GameObject playerDeckArea;
    public GameObject rivalDeckArea;
    public GameObject tradeArea;
    public GameObject turn;
    public Button endTurn;
    public Button stopTrading;
    public bool playerGoFirst;
    public bool playerGo;
    public bool rivalGo;
    public bool playerMerging;
    public bool rivalMerging;
    public TextMeshProUGUI playerHealth;
    public TextMeshProUGUI rivalHealth;
    public TextMeshProUGUI infoText;
    public bool waitingForTomorrowInput;
    public GameObject tomorrowInputObject;
    public GameObject battleUI;
    public AudioSource audioSource;
    public AudioClip mergeSound;
    public AudioClip hitSound;
    public bool playerWonYesterday;
    public bool drawYesterday;

    public Card selected1;
    public Card selected2;
    public GameObject merge;

    public delegate void NewTemplateCards(CardTemplate[] templates, List<Card> deck, GameObject deckArea);
    public delegate void RemoveTemplateCards(CardTemplate[] templates, List<Card> deck);
    public delegate void RemoveCards(Card[] templates, List<Card> deck);
    public delegate void Selected(Card cardSelected);
    public static NewTemplateCards onNewCards;
    public static RemoveTemplateCards onRemoveTemplateCards;
    public static RemoveCards onRemoveCards;
    public static Selected onSelected;
    public static Selected onDeselected;

    void Awake()
    {
        playerGoFirst = true;
    }

    void OnEnable()
    {
        onNewCards += SpawnCard;
        onRemoveCards += RemoveCard;
        onRemoveTemplateCards += RemoveCardWithTemplate;
        onSelected += Select;
        onDeselected += Deselect;
        StateMachine.onPlayerTurnOver += PlayerEndTurn;
        StateMachine.onStartTrade += EnableTrade;
        StateMachine.onMergeStart += DisableTrade;
        StateMachine.onMergeStart += MergeStart;
        StateMachine.onStartTrade += TurnStart;
        StateMachine.onPlayerStopTrading += PlayerStopTrading;
        StateMachine.onRivalStopTrading += RivalStopTrading;
        StateMachine.onRivalTurnOver += RivalEndTurn;
        StateMachine.onPlayerStopMerging += PlayerStopMerging;
        StateMachine.onRivalStopMerging += RivalStopMerging;
        StateMachine.onMergeEnd += BeginBattle;
    }

    void OnDisable()
    {
        onNewCards -= SpawnCard;
        onRemoveCards -= RemoveCard;
        onRemoveTemplateCards -= RemoveCardWithTemplate;
        onSelected -= Select;
        onDeselected -= Deselect;
        StateMachine.onStartTrade -= EnableTrade;
        StateMachine.onMergeStart -= DisableTrade;
        StateMachine.onMergeStart -= MergeStart;
        StateMachine.onStartTrade -= TurnStart;
        StateMachine.onPlayerStopTrading -= PlayerStopTrading;
        StateMachine.onRivalStopTrading -= RivalStopTrading;
        StateMachine.onPlayerTurnOver -= PlayerEndTurn;
        StateMachine.onRivalTurnOver -= RivalEndTurn;
        StateMachine.onPlayerStopMerging -= PlayerStopMerging;
        StateMachine.onRivalStopMerging -= RivalStopMerging;
        StateMachine.onMergeEnd -= BeginBattle;
    }

    void Start()
    {
        merge.GetComponent<Button>().onClick.AddListener(delegate { PlayerMerge(); });
        SelectionUpdater();
        UpdateTurn();
        infoText.text = "";
    }

    void Update()
    {
        if (waitingForTomorrowInput)
        {
            tomorrowInputObject.SetActive(true);
        }
        else
        {
            tomorrowInputObject.SetActive(false);
        }
        if (waitingForTomorrowInput && Input.GetKeyDown(KeyCode.Space))
        {
            if(StateMachine.day == 6)
            {
                result.playerScore = playerScore;
                result.rivalScore = rivalScore;
                SceneManager.LoadScene(2, LoadSceneMode.Single);
            }
            StateMachine.onStartTrade();
            waitingForTomorrowInput = false;
        }
    }

    void LateUpdate()
    {
        if (rivalGo == false && playerGo == false && (StateMachine.state == StateMachine.State.playerTurn || StateMachine.state == StateMachine.State.rivalTurn)) { StateMachine.onMergeStart(); UpdateTurn(); }
        if (rivalMerging == false && playerMerging == false && StateMachine.state == StateMachine.State.merge) { StateMachine.onMergeEnd(); UpdateTurn(); }
    }

    public void DelegatePlayerTurnOver()
    {
        StateMachine.onPlayerTurnOver();
    }

    public void DelegatePlayerStopTrading()
    {
        if (StateMachine.state == StateMachine.State.playerTurn)
        {
            StateMachine.onPlayerStopTrading();
        }
        else if (StateMachine.state == StateMachine.State.merge)
        {
            StateMachine.onPlayerStopMerging?.Invoke();
        }

    }

    void BeginBattle() { StartCoroutine(Battle()); }
    IEnumerator Battle()
    {
        rivalState.text = "Battling you";
        battleUI.SetActive(true);
        infoText.text = "";
        DeselectAll();
        int totalPlayerHealth = playerDeck.Select(x => x.template.maxHealth).Sum();
        int totalRivalHealth = rivalDeck.Select(x => x.template.maxHealth).Sum();
        playerHealth.text = totalPlayerHealth.ToString();
        rivalHealth.text = totalRivalHealth.ToString();

        List<Card> attackOrder = new List<Card>();
        using (var enumerator1 = playerDeck.GetEnumerator())
        using (var enumerator2 = rivalDeck.GetEnumerator())
        {
            int countBefore;
            do
            {
                countBefore = attackOrder.Count;
                if (enumerator1.MoveNext())
                    attackOrder.Add(enumerator1.Current);
                if (enumerator2.MoveNext())
                    attackOrder.Add(enumerator2.Current);
            } while (countBefore < attackOrder.Count);
        }
        yield return new WaitForSeconds(2f);
        
        for (int k = 0; k < attackOrder.Count; k++)
        {
            bool player = playerDeck.Contains(attackOrder[k]) ? true : false;
            Image imageK = attackOrder[k].gameObject.GetComponent<Image>();
            Color oldColor = imageK.color;
            imageK.color = Color.yellow;
            yield return new WaitForSeconds(0.8f);
            imageK.color = oldColor;
            if (player) { totalRivalHealth -= attackOrder[k].template.attack; } else { totalPlayerHealth -= attackOrder[k].template.attack; }
            if (player) { player = false; } else { player = true; }
            audioSource.PlayOneShot(hitSound);
            playerHealth.text = totalPlayerHealth.ToString();
            rivalHealth.text = totalRivalHealth.ToString();
            yield return new WaitForSeconds(0.8f);
            if (totalPlayerHealth <= 0) { BattleEnd(false); yield break; }
            else if (totalRivalHealth <= 0) { BattleEnd(true); yield break; }
        }
        if (totalPlayerHealth > totalRivalHealth)
        {
            infoText.text = "Neither side has won this battle, however as you have more health than your rival, you will be the second to trade tomorrow.";
            playerGoFirst = false;
        }
        else if (totalRivalHealth > totalPlayerHealth)
        {
            infoText.text = "Neither side has won this battle, however as your rival has more health than you, you will be the first to trade tomorrow.";
            playerGoFirst = true;
        }
        else
        {
            infoText.text = "Neither side has won this battle, and you have the same health... whoever traded first today, will also trade first tomorrow.";
        }
        drawYesterday = true;
        waitingForTomorrowInput = true;
    }

    void BattleEnd(bool playerWon)
    {
        playerGoFirst = playerWon ? true : false;
        if (playerWon)
        {
            playerScore++;
            infoText.text = "Congratulations! You have beaten your Rival today! This will be added to your final score. Both you and your opponent will receive a random Lvl 1 card tomorrow! Your rival will also trade first tomorrow.";
            playerGoFirst = false;
            playerWonYesterday = true;
            drawYesterday = false;
        }
        else
        {
            rivalScore++;
            infoText.text = "Your rival has beaten you today... this will be added to their final score :(. Both of you will get a random Lvl 1 card tomorrow. However, you will be able to go first tomorrow";
            playerGoFirst = true;
            playerWonYesterday = false;
            drawYesterday = false;
        }
        waitingForTomorrowInput = true;
    }

    void Select(Card selected)
    {
        if (StateMachine.state != StateMachine.State.merge) { return; }
        if (rivalDeck.Contains(selected)) { return; }

        if ((selected1 != null && selected1 == selected) || (selected2 != null && selected2 == selected)) { return; }
        if (selected1 == null) { selected1 = selected; }
        else if (selected2 == null) { selected2 = selected; }
        else { return; }
        SelectionUpdater();
    }

    void Deselect(Card selected)
    {
        if (StateMachine.state != StateMachine.State.merge) { return; }

        if (selected1 == selected) { selected1.selection.SetActive(false); ; selected1 = null; }
        else if (selected2 == selected) { selected2.selection.SetActive(false); ; selected2 = null; }
        else { return; }
        SelectionUpdater();
    }

    public void DeselectAll()
    {
        if(selected1 != null) { selected1.selection.SetActive(false); }
        if (selected2 != null) { selected2.selection.SetActive(false); }
        selected1 = null;
        selected2 = null;
        SelectionUpdater();
    }

    void MergeStart()
    {
        rivalState.text = "Merging";
        playerMerging = true; rivalMerging = true;
        stopTrading.interactable = true;
        rival.MergeDecisionDelay();
    }

    void PlayerStopMerging()
    {
        playerMerging = false;
        stopTrading.interactable = false;
    }

    void RivalStopMerging()
    {
        rivalState.text = "Finished Merging";
        rivalMerging = false;
    }

    void EnableTrade()
    {
        rivalState.text = "Trading";
        tradeArea.SetActive(true);
        DeselectAll();
        UpdateTurn();
    }

    void UpdateTurn()
    {
        switch (StateMachine.state)
        {
            case StateMachine.State.playerTurn:
                turn.GetComponent<TextMeshProUGUI>().text = "Your turn!";
                break;
            case StateMachine.State.rivalTurn:
                turn.GetComponent<TextMeshProUGUI>().text = "Rival's Turn";
                break;
            case StateMachine.State.merge:
                turn.GetComponent<TextMeshProUGUI>().text = "Merge your cards!";
                break;
            case StateMachine.State.NoAction:
                turn.GetComponent<TextMeshProUGUI>().text = "Battle!";
                break;
            default:
                break;
        }
    }

    void DisableTrade()
    {
        tradeArea.SetActive(false);
    }

    void SelectionUpdater()
    {
        if (selected1 != null) { selected1.selection.SetActive(true); }
        if (selected2 != null) { selected2.selection.SetActive(true); }
        if (selected1 != null && selected2 != null) { merge.SetActive(true); }
        else { merge.SetActive(false); }
    }

    void TurnStart()
    {
        battleUI.SetActive(false);
        turn.SetActive(true);
        playerGo = true;
        rivalGo = true;
        List<TraderTemplate> newTraders = new List<TraderTemplate>();
        if (gameRegister.allTraders.Count != 0 && gameRegister.allCards.Count != 0)
        {
            if (StateMachine.day == 0)
            {
                onNewCards(new CardTemplate[] { defaultCard, defaultCard, defaultCard }, playerDeck, playerDeckArea);
                onNewCards(new CardTemplate[] { defaultCard, defaultCard, defaultCard }, rivalDeck, rivalDeckArea);
            }
            else if (drawYesterday)
            {
                onNewCards(new CardTemplate[] { defaultCard, defaultCard }, playerDeck, playerDeckArea);
                onNewCards(new CardTemplate[] { defaultCard, defaultCard }, rivalDeck, rivalDeckArea);
            }
            if (playerWonYesterday && StateMachine.day > 0 && drawYesterday == false)
            {
                CardTemplate[] cards = gameRegister.allCards.FindAll(x => x.stage == 1).ToArray();
                onNewCards(new CardTemplate[] { cards[Random.Range(0, cards.Length)] }, playerDeck, playerDeckArea);
                onNewCards(new CardTemplate[] { cards[Random.Range(0, cards.Length)] }, rivalDeck, rivalDeckArea);
                onNewCards(new CardTemplate[] { defaultCard }, playerDeck, playerDeckArea);
                onNewCards(new CardTemplate[] { defaultCard, defaultCard }, rivalDeck, rivalDeckArea);
            }
            else if (playerWonYesterday == false && StateMachine.day > 0 && drawYesterday == false)
            {
                CardTemplate[] cards = gameRegister.allCards.FindAll(x => x.stage == 1).ToArray();
                onNewCards(new CardTemplate[] { cards[Random.Range(0, cards.Length)] }, playerDeck, playerDeckArea);
                onNewCards(new CardTemplate[] { cards[Random.Range(0, cards.Length)] }, rivalDeck, rivalDeckArea);
                onNewCards(new CardTemplate[] { defaultCard, defaultCard }, playerDeck, playerDeckArea);
            }
            for (int k = 0; k < 3; k++) { newTraders.Add(gameRegister.allTraders[Random.Range(0, gameRegister.allTraders.Count)]); }
            SpawnTrader(newTraders.ToArray());
        }
        if (playerGoFirst) { StateMachine.onRivalTurnOver?.Invoke(); }
        else { StateMachine.onPlayerTurnOver?.Invoke(); }
    }

    void PlayerEndTurn()
    {
        if (rivalGo)
        {
            StateMachine.state = StateMachine.State.rivalTurn;
            rival.TradeDecisionDelay();
            endTurn.interactable = false;
            stopTrading.interactable = false;
            UpdateTurn();
        }
    }

    void RivalEndTurn()
    {
        if (playerGo)
        {
            StateMachine.state = StateMachine.State.playerTurn;
            endTurn.interactable = true;
            stopTrading.interactable = true;
            UpdateTurn();
        }
        else
        {
            endTurn.interactable = false;
            stopTrading.interactable = false;
        }
    }

    void PlayerStopTrading()
    {
        rivalState.text = "Still trading";
        playerGo = false;
        if (rivalGo) { StateMachine.onPlayerTurnOver(); }
        endTurn.interactable = false;
        stopTrading.interactable = false;
    }

    void RivalStopTrading()
    {
        rivalState.text = "Waiting for you to finish";
        rivalGo = false;
        if (playerGo) { StateMachine.onRivalTurnOver(); }
        endTurn.interactable = false;
    }

    void SpawnCard(CardTemplate[] templates, List<Card> deck, GameObject deckArea)
    {
        foreach (CardTemplate k in templates)
        {
            Card spawned = Instantiate(emptyCard, deckArea.transform).GetComponent<Card>();
            spawned.Initialise(k);
            deck.Add(spawned);
        }
        Trader.onDeckChange?.Invoke();
    }

    void RemoveCard(Card[] templates, List<Card> deck)
    {
        foreach (Card k in templates)
        {
            Card toDestroy = deck.Find(x => x == k);
            deck.Remove(toDestroy);
            Destroy(toDestroy.gameObject);
        }
        Trader.onDeckChange?.Invoke();
    }

    void RemoveCardWithTemplate(CardTemplate[] templates, List<Card> deck)
    {
        foreach (CardTemplate k in templates)
        {
            Card toDestroy = deck.Find(x => x.template == k);
            deck.Remove(toDestroy);
            Destroy(toDestroy.gameObject);
        }
        Trader.onDeckChange?.Invoke();
    }

    void SpawnTrader(TraderTemplate[] template)
    {
        foreach (TraderTemplate k in template)
        {
            Trader spawned = Instantiate(emptyOffer, tradeArea.transform).GetComponent<Trader>();
            spawned.Initialise(k);
        }
    }

    void PlayerMerge()
    {
        if (selected1 == null || selected2 == null) { return; }
        if (selected1.template.type == selected2.template.type && selected1.template.stage == selected2.template.stage && selected1.template.stage != 4 && selected2.template.stage != 4 )
        {
            CardTemplate newCard;
            if (selected1.template.type != CardTemplate.Type.Nothing)
            {
                List<CardTemplate> matches = gameRegister.allCards.FindAll(x => x.type == selected1.template.type && x.stage - 1 == selected1.template.stage);
                newCard = matches[Random.Range(0, matches.Count)];
            }
            else
            {
                List<CardTemplate> matches = gameRegister.allCards.FindAll(x => x.stage - 1 == selected1.template.stage);
                newCard = matches[Random.Range(0, matches.Count)];
            }
            RemoveCard(new Card[] { selected1, selected2 }, playerDeck);
            onNewCards(new CardTemplate[] { newCard }, playerDeck, playerDeckArea);
            selected1 = null;
            selected2 = null;
            SelectionUpdater();
            audioSource.PlayOneShot(mergeSound);
        }

    }

    public void RivalMerge(Card selected1, Card selected2)
    {
        if (selected1 == null || selected2 == null) { return; }

        CardTemplate newCard;
        if (selected1.template.type != CardTemplate.Type.Nothing)
        {
            List<CardTemplate> matches = gameRegister.allCards.FindAll(x => x.type == selected1.template.type && x.stage - 1 == selected1.template.stage);
            newCard = matches[Random.Range(0, matches.Count)];
        }
        else
        {
            List<CardTemplate> matches = gameRegister.allCards.FindAll(x => x.stage - 1 == selected1.template.stage);
            newCard = matches[Random.Range(0, matches.Count)];
        }

        RemoveCard(new Card[] { selected1, selected2 }, rivalDeck);
        onNewCards(new CardTemplate[] { newCard }, rivalDeck, rivalDeckArea);
        selected1 = null;
        selected2 = null;
        SelectionUpdater();
        audioSource.PlayOneShot(mergeSound);
    }
}