﻿using System.Collections.Generic;

[System.Serializable]
public class Trades
{
    public int day;
    public List<CardTemplate> have = new List<CardTemplate>();
    public List<CardTemplate> want = new List<CardTemplate>();
}